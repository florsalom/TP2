/**
 * 
 */
/**
 * 
 */
module TP_2 {
	requires java.desktop;
}